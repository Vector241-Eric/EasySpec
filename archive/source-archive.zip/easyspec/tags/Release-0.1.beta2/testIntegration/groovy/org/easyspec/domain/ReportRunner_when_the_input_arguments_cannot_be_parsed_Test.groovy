package org.easyspec.domain

import org.easyspec.EasySpec
import org.easyspec.Context
import org.easyspec.Behavior
import org.easyspec.application.*

import org.codehaus.groovy.runtime.*

@EasySpec(interest='ReportRunner')
class ReportRunner_when_the_input_arguments_cannot_be_parsed_Test extends GroovyTestCase {
	String lastLogMessage
	ReportRunner runner
	def previousMetaClass

	def expectedUsage = '''
Run the EasySpec reporter for a given classpath.
    USAGE::

    ReportRunner [classpath] [outputPath]

    [classpath]    The classpath where the behaviors are (probably a .jar of your tests)
    [outoutPath]   The local path that you would like the reports to be written to

'''

	@Context('when the arguments cannot be parsed')
	public void setUp() {
		String[] args = ['someNonexistentJar.jar', 'someOutputPathThatDoesNotExist.jar', 'someExtraArgument']
		def logSpy = { message ->
			lastLogMessage = message
		}
		def logger = [log:logSpy]

		def loggerMetaClass = new TestingConsoleLoggerMetaClass(SimpleConsoleLogger.class)
		loggerMetaClass.logger = logger
		def invoker = InvokerHelper.instance

		previousMetaClass = invoker.metaRegistry.getMetaClass(SimpleConsoleLogger.class)
		invoker.metaRegistry.setMetaClass(SimpleConsoleLogger.class, loggerMetaClass)

		ReportRunner.main(args)
	}

	public void tearDown() {
		InvokerHelper.instance.metaRegistry.setMetaClass(SimpleConsoleLogger.class, previousMetaClass)
	}

	@Behavior
	void test_should_print_a_usage_message_and_quit() {
		assertEquals(expectedUsage, lastLogMessage)
	}
}