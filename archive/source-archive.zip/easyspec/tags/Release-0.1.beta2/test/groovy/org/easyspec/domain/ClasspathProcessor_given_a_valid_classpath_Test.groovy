package org.easyspec.domain

import org.easyspec.EasySpec
import org.easyspec.Context
import org.easyspec.Behavior
import org.easymock.IMocksControl

import static org.easymock.EasyMock.*

@EasySpec(interest='Classpath Processor')
class ClasspathProcessor_given_a_valid_classpath_Test extends GroovyTestCase {

	ClasspathProcessor processor
	IMocksControl mocks = createControl()
	String inputPath

	@Context('when asked to process classes from a valid classpath')
	public void setUp() {
		inputPath = 'foo.jar'

		def resultSpecs = new Specifications()
		def classes = new ArrayList<Class>()

		def classReader = mocks.createMock(ClasspathReader.class)
		expect(classReader.readClasses(inputPath)).andReturn(classes)

		def specParser = mocks.createMock(SpecParser.class)
		expect(specParser.parseSpecifications(classes)).andReturn(resultSpecs)

		def reporter = mocks.createMock(ReportGenerator.class)
		expect(reporter.generateReport(resultSpecs)).andReturn('')

		mocks.replay()

		processor = new ClasspathProcessor(classReader:classReader, specParser:specParser, reporter:reporter)
	}

	@Behavior
	public void test_should_retrieve_all_classes_from_the_specified_classpath() {
		processor.processClassPath(inputPath)
		mocks.verify()
	}

	@Behavior
	public void test_should_parse_the_specifications_from_the_classes() {
		processor.processClassPath(inputPath)
		mocks.verify()
	}

	@Behavior
	public void test_should_generate_a_report_from_the_specifications() {
		processor.processClassPath(inputPath)
		mocks.verify()
	}
}