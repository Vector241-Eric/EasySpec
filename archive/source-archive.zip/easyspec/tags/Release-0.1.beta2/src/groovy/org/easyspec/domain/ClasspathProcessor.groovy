package org.easyspec.domain

import org.easyspec.application.*

class ClasspathProcessor {
	ClasspathReader classReader = new ClassLoaderClassReader()
	SpecParser specParser = new SpecParserImpl()
	ReportGenerator reporter = new HtmlReportGenerator()

	def processClassPath(path) {
		def classes = classReader.readClasses(path)
		def specs = specParser.parseSpecifications(classes)
		reporter.generateReport(specs)
	}
}