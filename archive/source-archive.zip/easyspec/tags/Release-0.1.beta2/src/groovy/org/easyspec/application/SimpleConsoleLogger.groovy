package org.easyspec.application

class SimpleConsoleLogger {
	def log(message) {
		println message
	}
}