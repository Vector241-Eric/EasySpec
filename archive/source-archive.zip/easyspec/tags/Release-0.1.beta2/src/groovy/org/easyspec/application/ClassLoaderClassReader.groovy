package org.easyspec.application

import org.easyspec.domain.*
import java.util.jar.*

class ClassLoaderClassReader implements ClasspathReader {
	Collection<Class> readClasses(String classPath) {
		def jarName = new File(classPath)
		URL[] urls = [jarName.toURL()]
		def jarFile = new JarFile(jarName)
		def classLoader = new URLClassLoader(urls, Thread.currentThread().getContextClassLoader())

		def classes = new ArrayList()
		for (entry in jarFile.entries()) {
			def entryName = entry.toString()
			if (entryName.endsWith('.class')) {
				def className = entryName.replace('/', '.')
				className = className.substring(0, className.length() - 6)
				def clz = classLoader.loadClass(className, true)
				classes.add(clz)
			}
		}
		return classes
	}

	def getCleanClassName(className) {
		return className.replace('/', '.') - '.class'
	}

}