package org.easyspec.domain

interface ClasspathReader {
	Collection<Class> readClasses(String classPath)
}