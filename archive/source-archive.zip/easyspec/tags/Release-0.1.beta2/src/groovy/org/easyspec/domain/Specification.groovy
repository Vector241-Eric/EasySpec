package org.easyspec.domain

class Specification implements Comparable {
	String interest
	String context
	Behaviors behaviors = new Behaviors()

	boolean getIsImplemented() {
		for(behavior in behaviors) {
			if (!behavior.isImplemented) {
				return false
			}
		}
		return true
	}

	@Override
	boolean equals(other) {
		if (other.class != Specification.class) {
			return false
		}

		if (other.context != this.context) {
			return false
		}

		if (other.interest != this.interest) {
			return false
		}

		if (!(other.behaviors.containsAll(this.behaviors) && this.behaviors.containsAll(other.behaviors))) {
			return false
		}

		return true
	}

	public int compareTo(object) {
		Specification other = (Specification)object

		if (this.isImplemented != other.isImplemented) {
			if (!this.isImplemented) {
				return (-1)
			}
			return (1)
		}
		if (this.interest != other.interest) {
			return this.interest.compareTo(other.interest)
		}
		if (this.context != other.context) {
			return this.context.compareTo(other.context)
		}
		return 0
	}

	public String toString() {
		return "Specification interest '$interest', context: '$context'"
	}

	def addBehavior(behavior) {
		behaviors.add(behavior)
	}
}