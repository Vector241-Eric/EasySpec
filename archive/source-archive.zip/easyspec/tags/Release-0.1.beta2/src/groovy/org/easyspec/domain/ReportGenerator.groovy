package org.easyspec.domain

interface ReportGenerator {
	String generateReport(Specifications specs)
	String generateReport(Specifications specs, String title)
}