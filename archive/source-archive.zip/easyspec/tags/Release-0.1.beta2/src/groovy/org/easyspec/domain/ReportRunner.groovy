package org.easyspec.domain

import org.easyspec.application.*

class ReportRunner {
	def static log

	static void main(String[] args) {
		if (args.size() != 2) {
			helpme()
			return
		}

		def classpath = args[0]
		def outputPath = args[1]
		new ReportRunner().run(classpath, outputPath)
	}

	def run(classpath, outputPath) {
		forceFileExists(classpath)
		forceFileExists(outputPath)

		def reporter = new HtmlReportGenerator(path:outputPath)
		def classpathProcessor = new ClasspathProcessor(reporter:reporter)
		classpathProcessor.processClassPath(classpath)

	}

	def forceFileExists(file) {
		def f = new File(file)
		if (! f.exists()) {
			throw new FileNotFoundException ("The file or directory '$file' could not be opened or does not exist.")
		}
	}

	def static helpme() {
		def usage = '''
Run the EasySpec reporter for a given classpath.
    USAGE::

    ReportRunner [classpath] [outputPath]

    [classpath]    The classpath where the behaviors are (probably a .jar of your tests)
    [outoutPath]   The local path that you would like the reports to be written to

'''
		getLog().log(usage)

	}

	def static getLog() {
		if (log == null) {
			log = new SimpleConsoleLogger()
		}
		return log
	}
}