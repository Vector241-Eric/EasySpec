package org.easyspec.domain

interface SpecParser {
	Specifications parseSpecifications(inputClasses)
}