package org.easyspec.application

import org.easyspec.*
import groovy.mock.interceptor.MockFor

@EasySpec(interest='Class Loader Class Reader')
class ClassLoaderClassReader_when_filtering_by_package_name_Test extends GroovyTestCase {
	def loadedClasses = new ArrayList()

	@Context('when reading classes with a filter')
	public void setUp() {
		def path = 'some/fake/path.jar'
		def testPaths = ["com/test/foo.class", "com/test/bar.class", "com/other/package.class"]
		def classLoader = [loadClass:{name, resolve ->
			assert resolve == true
			loadedClasses.add(name)
		}]
		def classLoaderFactory = [createClassLoader:{file -> classLoader}]
		
		def jarParserMock = new MockFor(JarParser.class)
		def jarParser = [getEntryNames:{testPaths}]
		def reader = new ClassLoaderClassReader(classLoaderFactory:classLoaderFactory, jarParser:jarParser)
		reader.readClasses(path, "com.test")
	}
	
	void test_should_load_all_classes_regardless_of_package_or_name() {
		assert loadedClasses.size() == 2
		assert loadedClasses.contains('com.test.foo')
		assert loadedClasses.contains('com.test.bar')
	}
}