package org.easyspec.example

import org.easyspec.*

/**
 * Created by IntelliJ IDEA.
 * User: Youth
 * Date: Jul 30, 2008
 * Time: 12:37:23 AM
 * To change this template use File | Settings | File Templates.
 */
@EasySpec (interest = 'Character')
class Character_with_a_health_level_of_100_Test extends GroovyTestCase {
    def thorr

    @Context ("when the health level is 100")
    public void setUp() {
        thorr = Character.with().name('Thorr').and.health(100)
    }

    @Behavior
    public void test_should_have_a_health_of_80_after_taking_20_damage() {
        thorr.damage 20
        assertEquals 80, thorr.health
    }
}