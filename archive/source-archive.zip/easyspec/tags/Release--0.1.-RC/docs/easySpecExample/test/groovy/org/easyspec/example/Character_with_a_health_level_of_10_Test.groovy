package org.easyspec.example

import org.easyspec.*

/**
 * Created by IntelliJ IDEA.
 * User: Youth
 * Date: Jul 30, 2008
 * Time: 12:45:06 AM
 * To change this template use File | Settings | File Templates.
 */
@EasySpec (interest = 'Character')
class Character_with_a_health_level_of_10_Test extends GroovyTestCase {

    def thorr

    @Context ("when the health level is 10")
    public void setUp() {
        thorr = Character.with().name('Thorr').and.health(10)
    }

    @Behavior
    public void test_should_have_a_health_of_0_after_taking_20_damage() {
        thorr.damage 20
        assertEquals 0, thorr.health
    }

    @Behavior
    public void test_should_have_a_health_of_30_after_receiving_20_healing() {
        thorr.heal 20
        assertEquals 30, thorr.health
    }

    @Behavior
    public void test_should_have_a_health_of_100_after_receiving_100_healing() {
        thorr.heal 100
        assertEquals 100, thorr.health
    }

    @Behavior
    public void test_should_be_dead_after_receiving_10_damage() {
        thorr.damage 10
        assert thorr.isDead
    }
}