package org.easyspec.domain

import org.easyspec.application.*

class ReportRunner {
	def static log

	static void main(String[] args) {
		if (args.size() < 2 || args.size() > 3) {
			helpme()
			return
		}

		def classpath = args[0]
		def outputPath = args[1]
		def packageFilter = ''
		if (args.size() == 3) {
            packageFilter = args[2]
        }
		new ReportRunner().run(classpath, outputPath, packageFilter)
	}

	def run(classpath, outputPath, packageFilter) {
		forceFileExists(classpath)
		forceFileExists(outputPath)

		def reporter = new HtmlReportGenerator(path:outputPath)
		def classpathProcessor = new ClasspathProcessor(reporter:reporter)
		classpathProcessor.processClassPath(classpath, packageFilter)

	}

	def forceFileExists(file) {
		def f = new File(file)
		if (! f.exists()) {
			throw new FileNotFoundException ("The file or directory '$file' could not be opened or does not exist.")
		}
	}

	def static helpme() {
		def usage = '''
Run the EasySpec reporter for a given classpath.
    USAGE::

    ReportRunner [classpath] [outputPath] ([package])

    [classpath]    The classpath where the behaviors are (probably a .jar of your tests)
    [outoutPath]   The local path that you would like the reports to be written to
    [package]      (optional) the prefix for the package that you want included

'''
		getLog().log(usage)

	}

	def static getLog() {
		if (log == null) {
			log = new SimpleConsoleLogger()
		}
		return log
	}
}