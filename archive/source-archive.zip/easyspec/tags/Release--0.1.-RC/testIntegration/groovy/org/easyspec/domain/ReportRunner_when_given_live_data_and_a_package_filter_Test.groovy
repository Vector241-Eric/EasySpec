package org.easyspec.domain

import org.easyspec.EasySpec
import org.easyspec.Context
import org.easyspec.Behavior

@EasySpec(interest='ReportRunner')
class ReportRunner_when_given_live_data_and_a_package_filter_Test extends GroovyTestCase {
	def testPath = 'testIntegration/testOutput'
	def testDir = new File(testPath)
	def interestsParsed = new ArrayList()

	String[] args

	@Context('when given real input and output paths, with a package filter')
	public void setUp() {
		if (testDir.exists()) {
			deleteTestDirectory()
		}
		testDir.mkdir()
		args = ['testIntegration/data/easyspecTests.jar', testDir.toString(), 'org.easyspec.application']
		ReportRunner.main(args)
        def outputFile = new File(testPath + '/index.html')
        def html = new XmlParser().parse(outputFile)

        html.body.table.each {
            interestsParsed.add(it.tr[0].td[0].span.text().split(',')[0])
        }
	}

	public void tearDown() {
//		deleteTestDirectory()
	}

	def deleteTestDirectory() {
		//Only deletes first-order children of the test directory.
		testDir.eachFile { file ->
			file.delete()
		}
		testDir.delete()
	}

	@Behavior()
	void test_should_produce_a_report_containing_a_test_for_ClassLoaderClassReader() {
        String expected = 'ClassLoaderClassReader'
        def foundTheTest = interestsParsed.contains(expected)
        if (!foundTheTest) {
            println "Did not find the expected interest '$expected', but found these instead"
            interestsParsed.each { println it }
        }
        assertTrue 'We should find a test for ClassLoaderClassReader.  Did the test jar get changed?', foundTheTest
	}
}