package org.easyspec.domain

import org.easyspec.EasySpec
import org.easyspec.Context
import org.easyspec.Behavior
import org.easyspec.application.*

import groovy.mock.interceptor.MockFor


@EasySpec(interest='Classpath Processor')
class ClasspathProcessor_given_a_valid_classpath_and_package_filter_Test extends GroovyTestCase {

	def inputPath = 'foo.jar'
	def inputFilter = 'com.mycompany'
	def actualPath
	def inputClasses = new ArrayList<Class>()
	def actualClassesParsed
	def actualReportedSpecs
	def actualPrefix
	def resultSpecs = new Specifications()
	
	@Context('when asked to process classes from a valid classpath using a package prefix filter')
	public void setUp() {
		def reader = new MockFor(ClassLoaderClassReader.class)
		reader.demand.readClasses {path, prefix ->
			actualPath = path
			actualPrefix = prefix
			return inputClasses 
		}

		def parser = new MockFor(SpecParser.class)
		parser.demand.parseSpecifications { cls ->
			actualClassesParsed = cls
			return resultSpecs 
		}
		
		def reporter = new MockFor(HtmlReportGenerator.class)
		reporter.demand.generateReport { specs ->
			actualReportedSpecs = specs
			return ''
		}

		reader.use {
			parser.use {
				reporter.use {
					new ClasspathProcessor().processClassPath(inputPath, inputFilter)
				}
			}
		}
	}

	@Behavior
	public void test_should_retrieve_only_classes_that_are_on_the_classpath_and_match_the_filter() {
		assertEquals inputPath, actualPath
		assertEquals inputFilter, actualPrefix
	}

	@Behavior
	public void test_should_parse_the_specifications_from_the_classes() {
		assertEquals inputClasses, actualClassesParsed
	}

	@Behavior
	public void test_should_generate_a_report_from_the_specifications() {
		assertEquals resultSpecs, actualReportedSpecs
	}
}