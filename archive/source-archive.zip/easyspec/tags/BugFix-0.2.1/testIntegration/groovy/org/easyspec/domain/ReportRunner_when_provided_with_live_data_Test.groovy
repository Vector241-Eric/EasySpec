package org.easyspec.domain

import org.easyspec.EasySpec
import org.easyspec.Context
import org.easyspec.Behavior

@EasySpec(interest='ReportRunner')
class ReportRunner_when_provided_with_live_data_Test extends GroovyTestCase {
	def testPath = 'testIntegration/testOutput'
	def testDir = new File(testPath)

	String[] args

	@Context('when given real input and a real output path and no package filter')
	public void setUp() {
		if (testDir.exists()) {
			deleteTestDirectory()
		}
		testDir.mkdir()
		args = ['testIntegration/data/easyspecTests.jar', testDir.toString()]
		ReportRunner.main(args)
	}

	public void tearDown() {
		deleteTestDirectory()
	}

	def deleteTestDirectory() {
		//Only deletes first-order children of the test directory.
		testDir.eachFile { file ->
			file.delete()
		}
		testDir.delete()
	}

	@Behavior()
	void test_should_produce_a_report_containing_this_test() {
		def outputFile = new File(testPath + '/index.html')
		def html = new XmlParser().parse(outputFile)
		assertTrue('We should have a test in the first table', html.body.table[0].tr[0].td[0].span.text().length() > 0)
	}
}