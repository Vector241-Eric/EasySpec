package org.easyspec.domain

import org.easyspec.application.*

class ClasspathProcessor {
	ClassLoaderClassReader classReader = new ClassLoaderClassReader()
	SpecParser specParser = new SpecParser()
	HtmlReportGenerator reporter = new HtmlReportGenerator()

	def processClassPath(path, packagePrefix) {
		def classes = classReader.readClasses(path, packagePrefix)
		def specs = specParser.parseSpecifications(classes)
		reporter.generateReport(specs)
	}
}