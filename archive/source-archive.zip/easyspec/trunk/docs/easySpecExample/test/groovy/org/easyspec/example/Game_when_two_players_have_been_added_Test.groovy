package org.easyspec.example

import org.easyspec.*

/**
 * Created by IntelliJ IDEA.
 * User: Youth
 * Date: Jul 30, 2008
 * Time: 12:02:42 AM
 * To change this template use File | Settings | File Templates.
 */
@EasySpec (interest = 'A game')
class Game_when_two_players_have_been_added_Test extends GroovyTestCase {
    Game game
    def thorr = Character.with().name('Thorr').health(100)
    def astrid = Character.with().name('Astrid').with.health(100)

    @Context ("with characters Thorr and Astrid")
    public void setUp() {
        game = new Game()
        game.addCharacter thorr
        game.addCharacter astrid
    }

    @Behavior
    public void test_should_alternate_between_the_players_when_advancing_the_turn() {
        game.setTurn 'Thorr'
        assertEquals thorr, game.currentCharacter
        game.advanceTurn()
        assertEquals astrid, game.currentCharacter
        game.advanceTurn()
        assertEquals thorr, game.currentCharacter
    }

    @Behavior
    public void test_should_only_damage_the_current_player() {
        game.setTurn 'Thorr'
        game.assignDamage(20)
        assertEquals 80, thorr.health
        assertEquals 100, astrid.health
    }

    @Behavior
    public void test_should_remove_a_player_when_his_health_reaches_0() {
        game.setTurn 'Thorr'
        game.assignDamage 100
        game.advanceTurn()
        assertFalse 'Thorr should have been removed', game.hasCharacter('Thorr')
        assertEquals astrid, game.currentCharacter

        game.advanceTurn()
        assertEquals astrid, game.currentCharacter
    }
}