package org.easyspec.example

import org.easyspec.*
import groovy.util.GroovyTestCase

/**
 * Created by IntelliJ IDEA.
 * User: dea
 * Date: Jun 23, 2008
 * Time: 3:53:40 PM
 * To change this template use File | Settings | File Templates.
 */
@EasySpec(interest='A game')
class Game_when_new_Test extends GroovyTestCase {
    def game

    @Context("that is brand new")
    public void setUp() {
        game = new Game()
    }

    @Behavior
    public void test_should_not_report_that_a_player_is_in_the_game() {
        assertFalse "We should not have any players in the game", game.hasCharacter('Thorr')
    }
}