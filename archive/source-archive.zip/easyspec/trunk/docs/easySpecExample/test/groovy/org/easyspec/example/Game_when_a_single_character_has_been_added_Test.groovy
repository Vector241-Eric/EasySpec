package org.easyspec.example

import org.easyspec.*

/**
 * Created by IntelliJ IDEA.
 * User: dea
 * Date: Jun 16, 2008
 * Time: 9:34:26 AM
 * To change this template use File | Settings | File Templates.
 */
@EasySpec (interest = 'A game')
class Game_when_a_single_character_has_been_added_Test extends GroovyTestCase {
    def game
    def thorr = new Character('Thorr')

    @Context ("that only has Thorr added")
    public void setUp() {
        game = new Game()
        game.addCharacter(thorr)
    }

    @Behavior
    public void test_should_report_that_Thorr_is_in_the_game() {
        assertTrue "We should have added the player to the game", game.hasCharacter('Thorr')
    }

    @Behavior
    public void test_should_indicate_that_the_current_turn_belongs_to_Thorr() {
        assertEquals('The turn should belong to Thorr', thorr, game.currentCharacter)
    }

    @Behavior
    public void test_should_indicate_that_the_current_turn_belongs_to_Thorr_after_advancing_the_turn() {
        game.advanceTurn()
        assertEquals('The turn should belong to Thorr', thorr, game.currentCharacter)
    }
}