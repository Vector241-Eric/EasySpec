package org.easyspec.example

import org.easyspec.*

/**
 * Created by IntelliJ IDEA.
 * User: dea
 * Date: Jun 23, 2008
 * Time: 3:14:01 PM
 * To change this template use File | Settings | File Templates.
 */
@EasySpec(interest='A character')
class Character_when_freshly_created_Test extends GroovyTestCase {
    def character

    @Context("that has just been created")
    public void setUp() {
        character = new Character('Thorr')
    }

    @Behavior
    public void test_should_have_a_health_level_of_100() {
        assertEquals 100, character.health
    }

    @Behavior
    public void test_should_have_a_name() {
        assertEquals 'Thorr', character.name
    }
}