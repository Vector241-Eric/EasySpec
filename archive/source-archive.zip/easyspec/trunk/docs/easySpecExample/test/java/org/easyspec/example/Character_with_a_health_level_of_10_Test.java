package org.easyspec.example;

import org.easyspec.*;
import org.junit.*;
import static org.junit.Assert.*;

/**
 * Created by IntelliJ IDEA.
 * User: Youth
 * Date: Nov 5, 2008
 * Time: 12:45:06 AM
 */
@EasySpec (interest = "Character")
class Character_with_a_health_level_of_10_Test  {

    private Character thorr;

    @Context ("when the health level is 10")
    @Before
    public void setUp() {
        thorr = Character.with().name("Thorr").and().health(10);
    }

    @Behavior
    @Test
    public void test_should_have_a_health_of_0_after_taking_20_damage() {
        thorr.damage(20);
        assertEquals(0, thorr.getHealth());
    }

    @Behavior
    @Test
    public void test_should_have_a_health_of_30_after_receiving_20_healing() {
        thorr.heal (20);
        assertEquals (30, thorr.getHealth());
    }

    @Behavior
    @Test
    public void test_should_have_a_health_of_100_after_receiving_100_healing() {
        thorr.heal(100);
        assertEquals(100, thorr.getHealth());
    }

    @Behavior
    @Test
    public void test_should_be_dead_after_receiving_10_damage() {
        thorr.damage(10);
        assert thorr.getIsDead();
    }
}