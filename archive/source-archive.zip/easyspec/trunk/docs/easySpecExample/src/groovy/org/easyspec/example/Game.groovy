package org.easyspec.example

/**
 * Created by IntelliJ IDEA.
 * User: dea
 * Date: Jun 16, 2008
 * Time: 9:20:19 AM
 * To change this template use File | Settings | File Templates.
 */
class Game {
    def characters = new ArrayList()
    def currentTurnIndex = 0

    void addCharacter(String characterName) {
        addCharacter(new Character(characterName))
    }

    void addCharacter(Character character) {
        characters.add(character)
    }

    boolean hasCharacter(String characterName) {
        def existingCharacter = findCharacter(characterName)
        return existingCharacter != null
    }

    def findCharacter(String characterName) {
        return characters.find() { it.name == characterName }
    }

    Character getCurrentCharacter() {
        return characters[currentTurnIndex]
    }

    void advanceTurn() {
        currentTurnIndex = (currentTurnIndex + 1) % characters.size()
    }

    void setTurn(String characterName) {
        currentTurnIndex = characters.indexOf(findCharacter(characterName))
    }

    void assignDamage(damageAmount) {
        this.currentCharacter.damage damageAmount
        if (currentCharacter.isDead) {
            characters.remove currentCharacter
        }
    }

}