package org.easyspec.example
/**
 * Created by IntelliJ IDEA.
 * User: dea
 * Date: Jun 20, 2008
 * Time: 12:08:21 PM
 * To change this template use File | Settings | File Templates.
 */
class Character {
    def name
    def health

    public Character(String name) {
        this.name = name
        this.health = 100
    }

    def getWith() { return this }

    def getAnd() { return this }

    def and() {return this}

    static Character with() {
        return new Character()
    }

    def name(String name) {
        this.name = name
        return this
    }

    def health(int health) {
        this.health = health
        return this
    }

    def damage(damage) {
        health -= damage
        if (health < 0) health = 0
    }

    def heal(healing) {
        health += healing
        if (health > 100) health = 100
    }

    def getIsDead() {
        return health == 0
    }
}