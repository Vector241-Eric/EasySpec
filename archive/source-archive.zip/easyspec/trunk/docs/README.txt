You can find information about how to use EasySpec at the EasySpec wiki:
http://easyspec.googlecode.com/

You can email questions to easyspec@gmail.com

Source code is available for download at
http://easyspec.googlecode.com/svn/trunk or
http://easyspec.googlecode.com/svn/tags
