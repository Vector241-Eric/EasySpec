package org.easyspec.example;

public class Character {
    private String name;
    private int health;

    public Character(String name) {
        this.name = name;
        this.health = 100;
    }

    private Character() {
    	//Default for fluent interface
    }

    public Character having() { return this; }

    public Character  and() {return this; }

    public static Character with() {
        return new Character();
    }

    public Character name(String name) {
        this.name = name;
        return this;
    }

    public Character health(int health) {
        this.health = health;
        return this;
    }

    public Character damage(int damage) {
        health -= damage;
        if (health < 0) health = 0;
        return this;
    }

    public Character heal(int healing) {
        health += healing;
        if (health > 100) health = 100;
        return this;
    }

    public boolean isDead() {
        return health == 0;
    }

	protected String getName() {
		return name;
	}

	protected int getHealth() {
		return health;
	}
}