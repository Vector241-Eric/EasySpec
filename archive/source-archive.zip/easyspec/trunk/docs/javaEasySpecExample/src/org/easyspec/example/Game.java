package org.easyspec.example;

import java.util.ArrayList;
import java.util.List;

public class Game {
    private List<Character> characters = new ArrayList<Character>();
    private int currentTurnIndex = 0;

    public void addCharacter(String characterName) {
        addCharacter(new Character(characterName));
    }

    public void addCharacter(Character character) {
        characters.add(character);
    }

    public boolean hasCharacter(String characterName) {
    	Character existingCharacter = findCharacter(characterName);
        return existingCharacter != null;
    }

    private Character findCharacter(String characterName) {
    	for(Character c : characters) {
    		if (c.getName().equals(characterName)) {
    			return c;
    		}
    	}
    	return null;
    }

    public Character getCurrentCharacter() {
        return characters.get(currentTurnIndex);
    }

    public void advanceTurn() {
        currentTurnIndex = (currentTurnIndex + 1) % characters.size();
    }

    public void setTurn(String characterName) {
        currentTurnIndex = characters.indexOf(findCharacter(characterName));
    }

    public void assignDamage(int damageAmount) {
        Character currentCharacter = getCurrentCharacter();
		currentCharacter.damage( damageAmount);
        if (currentCharacter.isDead()) {
            characters.remove(currentCharacter);
        }
    }

}