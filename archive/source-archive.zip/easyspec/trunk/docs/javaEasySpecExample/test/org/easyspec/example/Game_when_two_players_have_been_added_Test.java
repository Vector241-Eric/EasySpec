package org.easyspec.example;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;

import org.easyspec.*;
import org.junit.Before;
import org.junit.Test;

@EasySpec (interest = "A game")
public class Game_when_two_players_have_been_added_Test {
    private Game game;
    private Character thorr = Character.with().name("Thorr").health(100);
    private Character astrid = Character.with().name("Astrid").and().health(100);

    @Context ("with characters Thorr and Astrid")
    @Before
    public void setUp() {
        game = new Game();
        game.addCharacter(thorr);
        game.addCharacter(astrid);
    }

    @Behavior
    @Test
    public void should_alternate_between_the_players_when_advancing_the_turn() {
        game.setTurn ("Thorr");
        assertEquals(thorr, game.getCurrentCharacter());
        game.advanceTurn();
        assertEquals(astrid, game.getCurrentCharacter());
        game.advanceTurn();
        assertEquals(thorr, game.getCurrentCharacter());
    }

    @Behavior
    @Test
    public void should_only_damage_the_current_player() {
        game.setTurn("Thorr");
        game.assignDamage(20);
        assertEquals(80, thorr.getHealth());
        assertEquals(100, astrid.getHealth());
    }

    @Behavior
    @Test
    public void should_remove_a_player_when_his_health_reaches_0() {
        game.setTurn("Thorr");
        game.assignDamage(100);
        game.advanceTurn();
        assertFalse("Thorr should have been removed", game.hasCharacter("Thorr"));
        assertEquals(astrid, game.getCurrentCharacter());

        game.advanceTurn();
        assertEquals(astrid, game.getCurrentCharacter());
    }
}