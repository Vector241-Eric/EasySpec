package org.easyspec.example;

import static org.junit.Assert.assertFalse;

import org.easyspec.*;
import org.junit.Before;
import org.junit.Test;

@EasySpec(interest="A game")
public class Game_when_new_Test {
    private Game game;

    @Context("that is brand new")
    @Before
    public void setUp() {
        game = new Game();
    }

    @Behavior
    @Test
    public void should_not_report_that_a_player_is_in_the_game() {
        assertFalse ("We should not have any players in the game", game.hasCharacter("Thorr"));
    }
}