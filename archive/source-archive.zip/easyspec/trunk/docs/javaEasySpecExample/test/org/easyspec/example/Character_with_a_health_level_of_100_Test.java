package org.easyspec.example;

import static org.junit.Assert.assertEquals;

import org.easyspec.*;
import org.junit.Before;
import org.junit.Test;

@EasySpec (interest = "A character")
public class Character_with_a_health_level_of_100_Test {
    Character thorr;

    @Context ("that has a health level of 100")
    @Before
    public void setUp() {
        thorr = Character.with().name("Thorr").and().health(100);
    }

    @Behavior
    @Test
    public void should_have_a_health_of_80_after_taking_20_damage() {
        thorr.damage(20);
        assertEquals(80, thorr.getHealth());
    }
}