package org.easyspec.example;

import static org.junit.Assert.assertEquals;

import org.easyspec.*;
import org.junit.Before;
import org.junit.Test;

@EasySpec(interest="A character")
public class Character_when_freshly_created_Test {
    private Character character;

    @Context("that has just been created")
    @Before
    public void setUp() {
        character = new Character("Thorr");
    }

    @Behavior
    @Test
    public void should_have_a_health_level_of_100() {
        assertEquals(100, character.getHealth());
    }

    @Behavior
    @Test
    public void should_have_a_name() {
        assertEquals("Thorr", character.getName());
    }
}