package org.easyspec.example;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;

import org.easyspec.Behavior;
import org.easyspec.Context;
import org.easyspec.EasySpec;
import org.junit.Before;
import org.junit.Test;

@EasySpec (interest = "A game")
public class Game_when_a_single_character_has_been_added_Test {
    private Game game;
    private Character thorr = new Character("Thorr");

    @Context ("that only has Thorr added")
    @Before
    public void setUp() {
        game = new Game();
        game.addCharacter(thorr);
    }

    @Behavior
    @Test
    public void should_report_that_Thorr_is_in_the_game() {
        assertTrue("We should have added the player to the game", game.hasCharacter("Thorr"));
    }

    @Behavior
    @Test
    public void should_indicate_that_the_current_turn_belongs_to_Thorr() {
        assertEquals("The turn should belong to Thorr", thorr, game.getCurrentCharacter());
    }

    @Behavior
    @Test
    public void should_indicate_that_the_current_turn_belongs_to_Thorr_after_advancing_the_turn() {
        game.advanceTurn();
        assertEquals("The turn should belong to Thorr", thorr, game.getCurrentCharacter());
    }
}