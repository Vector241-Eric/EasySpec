package org.easyspec.domain

import org.easyspec.EasySpec
import org.easyspec.Context
import org.easyspec.Behavior

@EasySpec(interest='ReportRunner')
class ReportRunner_when_given_bad_classpath_Test extends GroovyTestCase {
	String[] args

	@Context('when the classpath is bad')
	public void setUp() {
		args = ['doesNotExist.jar', '.']
	}

	@Behavior
	void test_should_report_that_the_path_is_bad_and_quit() {
		try {
			ReportRunner.main(args)
		} catch (FileNotFoundException e) {
			assertEquals("The file or directory 'doesNotExist.jar' could not be opened or does not exist.", e.message)
			return
		}
		fail('Expected Exception was not thrown')
	}
}