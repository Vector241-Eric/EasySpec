package org.easyspec.application

import org.easyspec.EasySpec
import org.easyspec.Context
import org.easyspec.Behavior

@EasySpec(interest='ClassLoaderClassReader')
class ClassLoaderClassReader_when_given_valid_input_Test extends GroovyTestCase {
	def loadedClasses

	@Context('when given a valid classpath')
	public void setUp() {
		def path = 'testIntegration/data/easyspecTests.jar'
		def reader = new ClassLoaderClassReader()
		loadedClasses = reader.readClasses(path)
	}

	@Behavior
	void test_should_load_the_classes() {
		assertTrue('We should be able to find the class.  Who moved my cheese?', loadedClasses.contains(this.class))
	}
}