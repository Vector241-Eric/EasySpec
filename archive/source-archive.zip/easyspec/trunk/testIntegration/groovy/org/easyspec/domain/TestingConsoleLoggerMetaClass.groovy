package org.easyspec.domain

class TestingConsoleLoggerMetaClass extends groovy.lang.DelegatingMetaClass {
	def logger

	TestingConsoleLoggerMetaClass(final Class clz) {
		super (clz)
		initialize()
	}

	@Override
	public Object invokeConstructor(Object[] arguments) {
		return logger
	}
}