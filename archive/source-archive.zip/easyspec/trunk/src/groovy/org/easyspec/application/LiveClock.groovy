package org.easyspec.application

class LiveClock {
	def currentTime() {
		return Calendar.getInstance().getTime()
	}
}