package org.easyspec.domain

class Behaviors extends ArrayList<Behavior> {

}