package org.easyspec.application;

public class ClassLoaderFactory {

	def createClassLoader(File jar) {
		URL[] urls = [jar.toURL()]
		def classLoader = new URLClassLoader(urls, Thread.currentThread().getContextClassLoader());

		return classLoader
		
	}
}
