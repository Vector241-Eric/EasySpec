package org.easyspec

import org.easyspec.domain.ReportRunner
import org.easyspec.application.CommandLineParser
import org.easyspec.application.SimpleConsoleLogger
import org.easyspec.application.EasySpecLogger

class EasySpecReport {

    public static String TEST_JAR = 'test-jar'
    public static String PACKAGE = 'package'
    public static String OUTPUT_PATH = 'output-path'

    private EasySpecLogger logger

    static void main(String[] args) {
        new EasySpecReport().go args
    }

    def go(args) {
        CommandLineParser parser = new CommandLineParser()
        def argumentMap = parser.parse(args)
        Object jar = argumentMap[TEST_JAR]
        Object outputPath = argumentMap['output-path']

        if (outputPath == null || jar == null) {
            helpme()
            return
        }

        ReportRunner runner = new ReportRunner()
        def filter = argumentMap[PACKAGE]
        if (filter == null) filter = ''


        runner.run(jar, outputPath, filter)
    }

    def helpme() {
        def usage = '''
Run the EasySpec reporter for a given classpath.
    USAGE::

    EasySpecReport --test-jar [jar] --output-path [outputPath] (--package [package])

    [jar]          The jar where the behaviors are
    [outoutPath]   The local path that you would like the reports to be written to
    [package]      (optional) the prefix for the package that you want included

'''
        getLog().log(usage)

    }
    
    def getLog() {
        if (logger == null) {
            logger = new SimpleConsoleLogger()
        }
        return logger
    }
}