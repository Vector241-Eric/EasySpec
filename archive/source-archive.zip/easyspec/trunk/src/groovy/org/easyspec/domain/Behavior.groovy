package org.easyspec.domain

class Behavior {
	String detail
	boolean isImplemented = true

	@Override
	String toString() {
		return detail
	}

	@Override
	boolean equals(other) {
		if (other.class != Behavior.class) {
			return false
		}

		if (other.detail != this.detail) {
			return false
		}

		return true
	}
}