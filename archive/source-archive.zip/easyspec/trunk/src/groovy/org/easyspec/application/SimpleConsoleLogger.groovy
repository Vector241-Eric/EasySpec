package org.easyspec.application

class SimpleConsoleLogger implements EasySpecLogger {
	void log(String message) {
		println message
	}
}