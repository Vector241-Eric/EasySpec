package org.easyspec.application;

import java.util.jar.*

public class JarParser {

	def getEntryNames(File file) {
		def jar = new JarFile(file)
		
		def entryNames = new ArrayList()
		for (entry in jar.entries()) {
			entryNames.add(entry.toString())
		}
		return entryNames
	}
}
