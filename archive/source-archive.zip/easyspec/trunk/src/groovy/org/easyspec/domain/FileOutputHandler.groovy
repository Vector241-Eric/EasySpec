package org.easyspec.domain

interface FileOutputHandler {
	def writeToFile(String fullPath, String contents)
}