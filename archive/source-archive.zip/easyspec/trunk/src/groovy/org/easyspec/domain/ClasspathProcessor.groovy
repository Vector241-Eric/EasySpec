package org.easyspec.domain

import org.easyspec.application.*

class ClasspathProcessor {
  ClassLoaderClassReader classReader = new ClassLoaderClassReader()
  SpecParser specParser = new SpecParser()
  def reporters = [new HtmlReportGenerator(), new XmlReportGenerator()]

  def processClassPath(path, packagePrefix) {
    def classes = classReader.readClasses(path, packagePrefix)
    def specs = specParser.parseSpecifications(classes)
    for (reporter in reporters) {
      reporter.generateReport(specs)
    }
  }
}