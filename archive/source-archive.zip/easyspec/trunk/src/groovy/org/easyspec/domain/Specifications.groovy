package org.easyspec.domain

class Specifications extends TreeSet<Specification> {
	public boolean getAreImplemented() {
		this.each { spec ->
			if (!spec.isImplemented) {
				return false
			}
		}

		return true
	}
}