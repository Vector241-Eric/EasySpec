package org.easyspec.application
/**
 * Created by IntelliJ IDEA.
 * User: dea
 * Date: Dec 10, 2008
 * Time: 1:42:37 PM
 * To change this template use File | Settings | File Templates.
 */
public interface EasySpecLogger {
    void log(String message)
}