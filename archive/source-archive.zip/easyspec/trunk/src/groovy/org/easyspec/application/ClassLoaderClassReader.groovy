package org.easyspec.application

import org.easyspec.domain.*

class ClassLoaderClassReader {
	def classLoaderFactory = new ClassLoaderFactory()
	def jarParser = new JarParser()
	
	Collection<Class> readClasses(String classPath) {
		return readClasses(classPath, "")
	}
	
	Collection<Class> readClasses(String classPath, String packagePrefix) {
		def file = new File(classPath)
		def classLoader = classLoaderFactory.createClassLoader(file)
		
		def classes = new ArrayList()
		for (entryName in jarParser.getEntryNames(file)) {
			if (entryName.endsWith('.class')) {
				def className = entryName.replace('/', '.')
				if (className.startsWith(packagePrefix)) {
					className = className.substring(0, className.length() - 6)
					def clz = classLoader.loadClass(className, true)
					classes.add(clz)
				}
			}
		}
		return classes
	}

	def getCleanClassName(className) {
		return className.replace('/', '.') - '.class'
	}

}