package org.easyspec.domain

import org.easyspec.application.LocalDiskOutput
import org.easyspec.application.LiveClock
import groovy.xml.MarkupBuilder
import java.text.SimpleDateFormat

/**
 * Created by IntelliJ IDEA.
 * User: dea
 * Date: Mar 27, 2009
 * Time: 11:39:32 AM
 * To change this template use File | Settings | File Templates.
 */

public class XmlReportGenerator {
	FileOutputHandler fileSystem = new LocalDiskOutput()
	String path
	String outputFileName = 'snapshot.xml'
	def clock = new LiveClock()

	String generateReport(Specifications specifications) {
		return generateReport(specifications, 'EasySpec Report')
	}

	String generateReport(Specifications specifications, String title) {
		def outputFile
		if (path != null) {
			outputFile = "$path/$outputFileName"
		}
		else {
			outputFile = outputFileName
		}
		fileSystem.writeToFile(outputFile, generate(specifications, title))
		return outputFileName
	}

	def generate(specifications, titleText) {
		def writer = new StringWriter()
		def xml = new MarkupBuilder(writer)
		def format = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss aa")

      xml.snapshot(date:format.format(clock.currentTime())) {
              specifications.each { spec ->
                  def idString = spec.interest + spec.context
                  idString = idString.replaceAll(' ', '')
                  specification(interest:spec.interest,  namespace:spec.javaPackage) {
                      //The Header Row has the interest and context
                    context "$spec.context"
                    spec.behaviors.each { b ->
                      behavior(implemented:b.isImplemented, passing:true, "$b.detail")
                  }
              }
          }
      }

		return writer.toString();
	}
}