package org.easyspec.application

import org.easyspec.domain.*

class LocalDiskOutput implements FileOutputHandler{
	def writeToFile(String fullPath, String contents) {
		new File(fullPath).write(contents)
	}
}