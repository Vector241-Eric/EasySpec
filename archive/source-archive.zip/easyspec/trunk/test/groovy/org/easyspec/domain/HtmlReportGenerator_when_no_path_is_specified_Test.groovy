package org.easyspec.domain

import org.easyspec.EasySpec
import org.easyspec.Context
import org.easyspec.Behavior
import groovy.xml.*

@EasySpec(interest='Html Report Generator')
class HtmlReportGenerator_when_no_path_is_specified_Test extends GroovyTestCase {
	String htmlString
	String outputFilePath

	@Context('when no path is specified')
	public void setUp() {
		def testFileSystem = { fileName, output ->
			htmlString = output
			outputFilePath = fileName
		    return true
		} as FileOutputHandler

		def specs = new Specifications()

		def generator = new HtmlReportGenerator(fileSystem: testFileSystem)

		generator.generateReport(specs)
	}

	@Behavior()
	public void test_should_write_to_a_file_in_the_current_path() {
		assertEquals('index.html', outputFilePath)
	}
}