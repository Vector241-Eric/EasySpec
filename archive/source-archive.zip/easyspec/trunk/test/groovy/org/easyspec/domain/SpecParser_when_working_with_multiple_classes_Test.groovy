package org.easyspec.domain

import org.easyspec.Behavior
import org.easyspec.EasySpec
import org.easyspec.Context

@EasySpec(interest='Spec Parser')
class SpecParser_when_working_with_multiple_classes_Test extends GroovyTestCase {
	Specifications specifications

	@Context("when working with a collection of classes")
	public void setUp() {
		def inputClasses = new ArrayList()
		inputClasses.add(IsSpecOne.class)
		inputClasses.add(IsSpecTwo.class)
		inputClasses.add(IsNotSpec.class)

		def specParser = new SpecParser()
		specifications = specParser.parseSpecifications(inputClasses)

	}

	@Behavior
	void test_should_parse_specifications_for_each_specification_class() {
		assertEquals(2, specifications.size())
	}
}