package org.easyspec.domain

import org.easyspec.EasySpec
import org.easyspec.Context
import org.easyspec.Behavior
import org.easyspec.*

import groovy.xml.*

public class XmlReportGenerator_when_processing_specifications_Test extends GroovyTestCase {
	String xmlString
	String outputFilePath
	Node xml
	def testTime
	def testTitle
	def createdFileName

	@Context('when processing specifications')
	public void setUp() {
		def testFileSystem = { fileName, output ->
			xmlString = output
			outputFilePath = fileName
		    return true
		} as FileOutputHandler

		Calendar calendar = Calendar.getInstance()
		calendar.set(Calendar.YEAR, 2007)
		calendar.set(Calendar.MONTH, Calendar.OCTOBER)
		calendar.set(Calendar.DAY_OF_MONTH, 8)
		calendar.set(Calendar.HOUR, 10)
		calendar.set(Calendar.AM_PM, Calendar.AM)
		calendar.set(Calendar.MINUTE, 5)
		calendar.set(Calendar.SECOND, 4)
		testTime = calendar.getTime()
		def clockStub = [currentTime:{ return testTime }]

		def spec1 = new Specification(interest:'My Object', context:'when doing something interesting', javaPackage:'org.boring')
		spec1.addBehavior(new domain.Behavior(detail:'should do something', isImplemented:true))
		spec1.addBehavior(new domain.Behavior(detail:'should do something else', isImplemented:true))

		def spec2 = new Specification(interest:'My Fun Object', context:'when doing something interesting', javaPackage:'org.boring.too')
		spec2.addBehavior(new domain.Behavior(detail:'should do something fun', isImplemented:true))
		spec2.addBehavior(new domain.Behavior(detail:'should do something else fun', isImplemented:false))

		def specs = new Specifications()
		specs.add(spec1)
		specs.add(spec2)

		testTitle = 'Some Report Title'

		def generator = new XmlReportGenerator(path:'test/path', fileSystem: testFileSystem, clock:clockStub)

		createdFileName = generator.generateReport(specs, testTitle)

		xml = new XmlParser().parseText(xmlString)
	}

	@Behavior()
	public void test_should_send_xml_output_to_a_file_named_index_in_the_specified_path() {
		assert outputFilePath == 'test/path/snapshot.xml'
	}

	@Behavior()
	public void test_should_set_the_root_node_to_snapshot() {
		assert xml.name() == 'snapshot'
      assertEquals '2007-10-08 10:05:04 AM', xml.'@date'
	}

	@Behavior()
	public void test_should_generate_an_entry_for_each_specification() {
	  assert xml.specification.size() == 2
      assertEquals 'org.boring.too', xml.specification[0].'@namespace'
      assertEquals 'My Fun Object', xml.specification[0].'@interest'
      assertEquals 'org.boring', xml.specification[1].'@namespace'
      assertEquals 'My Object', xml.specification[1].'@interest'
	}


	@Behavior()
	public void test_should_include_context_with_each_specification_entry() {
		assertEquals('when doing something interesting', xml.specification[0].context[0].text())
		assertEquals('when doing something interesting', xml.specification[1].context[0].text())
	}

	@Behavior()
	public void test_should_report_individual_behaviors() {
		assertEquals('should do something fun', xml.specification[0].behavior[0].text())
		assertEquals('should do something else fun', xml.specification[0].behavior[1].text())

		assertEquals('should do something', xml.specification[1].behavior[0].text())
		assertEquals('should do something else', xml.specification[1].behavior[1].text())
	}

	@Behavior()
	public void test_should_set_implemented_and_passing() {
      assertEquals('true', xml.specification[0].behavior[0].'@passing')
      assertEquals('true', xml.specification[0].behavior[1].'@passing')
      assertEquals('true', xml.specification[1].behavior[0].'@passing')
      assertEquals('true', xml.specification[1].behavior[1].'@passing')

      assertEquals('true', xml.specification[0].behavior[0].'@implemented')
      assertEquals('false', xml.specification[0].behavior[1].'@implemented')
      assertEquals('true', xml.specification[1].behavior[0].'@implemented')
      assertEquals('true', xml.specification[1].behavior[1].'@implemented')
	}

	@Behavior
	public void test_should_indicate_the_name_of_the_file_that_was_created() {
		assertEquals('snapshot.xml', createdFileName)
	}
}