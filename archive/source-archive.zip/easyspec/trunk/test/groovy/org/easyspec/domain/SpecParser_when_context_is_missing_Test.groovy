package org.easyspec.domain

import org.easyspec.EasySpec
import org.easyspec.Context
import org.easyspec.Behavior

/**
 * Created by IntelliJ IDEA.
 * User: dea
 * Date: Dec 17, 2008
 * Time: 2:51:59 PM
 * To change this template use File | Settings | File Templates.
 */

@EasySpec(interest='Spec Parser')
class SpecParser_when_context_is_missing_Test extends GroovyTestCase {

    def thrownException

    @Context("when the specification context is missing")
    public void setUp() {
        def inputClasses = new ArrayList()
        inputClasses.add(IsSpecOne.class)
        inputClasses.add(IsSpecButNotContext.class)
        inputClasses.add(IsNotSpec.class)

        def specParser = new SpecParser()

        try {
            specParser.parseSpecifications(inputClasses)
        } catch (RuntimeException e) {
            thrownException = e
        }

    }

    @Behavior
    void test_should_experience_a_fatal_error() {
        assertNotNull ("We should have a runtime exception", thrownException)

    }

    @Behavior
    void test_should_report_the_failing_class_name() {
        String expected = 'class org.easyspec.domain.IsSpecButNotContext is an EasySpec specification, but does not have the @Context annotation.'
        assertEquals("Should have the class name",expected,thrownException.message)
    }



}