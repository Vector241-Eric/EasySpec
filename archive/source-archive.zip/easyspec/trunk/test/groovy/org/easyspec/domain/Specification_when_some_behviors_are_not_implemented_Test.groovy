package org.easyspec.domain

import org.easyspec.EasySpec
import org.easyspec.Context
import org.easyspec.Behavior
import org.easyspec.*

@EasySpec(interest='Specification')
class Specification_when_some_behviors_are_not_implemented_Test extends GroovyTestCase {
	Specification spec

	@Context('when some behaviors are not implemented')
	public void setUp() {
		spec = new Specification()
		spec.addBehavior(new domain.Behavior(isImplemented:true))
		spec.addBehavior(new domain.Behavior(isImplemented:false))
	}

	@Behavior
	void test_should_not_be_implemented() {
		assert spec.isImplemented == false
	}
}