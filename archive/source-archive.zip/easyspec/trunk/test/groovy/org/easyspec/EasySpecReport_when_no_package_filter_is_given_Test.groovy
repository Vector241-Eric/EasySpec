package org.easyspec

import org.easyspec.domain.ReportRunner
import groovy.mock.interceptor.MockFor
import org.easyspec.application.CommandLineParser

@EasySpec(interest = 'Easy Spec Report Generator')
class EasySpecReport_when_no_package_filter_is_given_Test extends GroovyTestCase {

    def actualClasspath
    def actualOutputPath
    def actualPackageFilter

    @Context('when the input jar and output path are specified without a filter on the command line')
    public void setUp() {
        def reporter = new MockFor(ReportRunner.class)
        reporter.demand.run {classpath, outputPath, packageFilter ->
            actualClasspath = classpath
            actualOutputPath = outputPath
            actualPackageFilter = packageFilter
        }

        def actualArgsNotImportant = ['1', '2', '3'].toArray()
        def map = [(EasySpecReport.TEST_JAR) : 'my_test.jar', (EasySpecReport.OUTPUT_PATH) : 'my.output.path']

        def parser = new MockFor(CommandLineParser.class)
        parser.demand.parse {passedArgs ->
            assertEquals (actualArgsNotImportant, passedArgs)
            return map
        }

        parser.use {
            reporter.use {
                EasySpecReport easySpecReport = new EasySpecReport()
                easySpecReport.go(actualArgsNotImportant)
            }
        }
    }

    @Behavior
    public void test_should_run_the_report_for_the_specified_input_and_output() {
        assertEquals('my_test.jar', actualClasspath)
        assertEquals('my.output.path', actualOutputPath)
    }

    @Behavior
    public void test_should_run_the_report_without_a_package_filter() {
        assertNotNull ('should not run with a null filter', actualPackageFilter)
        assertEquals('', actualPackageFilter)
    }
}
