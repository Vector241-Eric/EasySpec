package org.easyspec.domain

import org.easyspec.EasySpec
import org.easyspec.Context
import org.easyspec.Behavior
import org.easyspec.*

import groovy.xml.*

@EasySpec(interest='Html Report Generator')
class HtmlReportGenerator_when_processing_specifications_of_the_same_interest_Test extends GroovyTestCase {
	String htmlString
	String outputFilePath
	Node html

	@Context('when processing specifications')
	public void setUp() {
		def testFileSystem = { fileName, output ->
			htmlString = output
			outputFilePath = fileName
		    return true
		} as FileOutputHandler

		def spec1 = new Specification(interest:'Object 1', context:'Context 1')
		spec1.addBehavior(new domain.Behavior(detail:'Behavior 1'))
		spec1.addBehavior(new domain.Behavior(detail:'Behavior 1.2'))

		def spec2 = new Specification(interest:'Object 1', context:'Context 2')
		spec2.addBehavior(new domain.Behavior(detail:'Behavior 2'))
		spec2.addBehavior(new domain.Behavior(detail:'Behavior 2.2'))

		def specs = new Specifications()
		specs.add(spec1)
		specs.add(spec2)

		def generator = new HtmlReportGenerator(path:'test/path', fileSystem: testFileSystem)

		generator.generateReport(specs)

		html = new XmlParser().parseText(htmlString)
	}

	@Behavior()
	public void test_should_generate_unique_ids_for_the_specifications() {
		assert html.body.table.size() == 2
		assertEquals('Object1Context1', html.body.table[0].'@id')
		assertEquals('Object1Context2', html.body.table[1].'@id')
	}
}