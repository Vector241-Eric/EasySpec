package org.easyspec.domain

import org.easyspec.EasySpec
import org.easyspec.Context
import org.easyspec.Behavior

@EasySpec(interest='Specifications Collection')
class Specifications_when_populated_Test extends GroovyTestCase {

	Specifications specs
	def spec1
	def spec2

	@Context('when populated with implemented specifications')
	public void setUp() {
		specs = new Specifications()

		spec2 = new Specification(interest:'Foo', context:'FooContext2')
		spec1 = new Specification(interest:'Foo', context:'FooContext')
		specs.add(spec2)
		specs.add(spec1)
	}

	@Behavior
	public void test_should_sort_specification_elements() {
		assertEquals(spec1, specs.first())
		assertEquals(spec2, specs.last())
	}

	@Behavior
	public void test_should_not_be_equal_to_another_collection_with_different_specifications() {
		def other = new Specifications()
		other.addAll(specs)
		other.add(new Specification(interest:'Bar', context:'BarContext'))

		assertFalse(other.equals(specs))
		assertFalse(specs.equals(other))
	}

	@Behavior
	public void test_should_never_be_equal_to_something_that_is_not_a_specifications() {
		assertFalse(specs.equals('some string'))
	}

	@Behavior
	public void test_should_indicate_that_all_specifications_are_implemented() {
		assertTrue(specs.areImplemented)
	}
}