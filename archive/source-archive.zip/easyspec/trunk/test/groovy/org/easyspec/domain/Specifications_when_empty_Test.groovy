package org.easyspec.domain

import org.easyspec.EasySpec
import org.easyspec.Context
import org.easyspec.Behavior

@EasySpec(interest='Specifications Collection')
class Specifications_when_empty_Test extends GroovyTestCase {

	Specifications specs

	@Context('when empty')
	public void setUp() {
		specs = new Specifications()
	}

	@Behavior
	public void test_should_be_equal_to_other_empty_specifications() {
		def other = new Specifications()
		assertTrue(other.equals(specs))
		assertTrue(specs.equals(other))
	}
}