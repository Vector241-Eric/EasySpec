package org.easyspec

import org.easyspec.domain.ReportRunner
import groovy.mock.interceptor.MockFor
import org.easyspec.application.CommandLineParser
import groovy.mock.interceptor.StubFor
import org.easyspec.application.EasySpecLogger

@EasySpec(interest = 'Easy Spec Report Generator')
class EasySpecReport_when_output_argument_is_missing_Test extends GroovyTestCase {

    def actualClasspath
    def actualOutputPath
    def actualPackageFilter
    def logged
    def reportRun = false

    @Context('when the output parameter is not specified on the command line')
    public void setUp() {
        def reporter = new StubFor(ReportRunner.class)
        reporter.demand.run {classpath, outputPath, packageFilter ->
            reportRun = true
        }

        def actualArgsNotImportant = ['1', '2', '3'].toArray()
        def map = [(EasySpecReport.TEST_JAR) : 'my_test.jar']

        def logger = { m -> logged = m } as EasySpecLogger

        def parser = new MockFor(CommandLineParser.class)
        parser.demand.parse {passedArgs ->
            assertEquals (actualArgsNotImportant, passedArgs)
            return map
        }

        

        parser.use {
            reporter.use {
                EasySpecReport easySpecReport = new EasySpecReport(logger:logger)
                easySpecReport.go(actualArgsNotImportant)
            }
        }
    }

    @Behavior
    public void test_should_print_a_usage_message() {
      assertNotNull('We should have logged usage', logged)
    }

    @Behavior
    public void test_should_not_run_a_report() {
      assertFalse ('We should not have run a report with bad args', reportRun)
    }
}
