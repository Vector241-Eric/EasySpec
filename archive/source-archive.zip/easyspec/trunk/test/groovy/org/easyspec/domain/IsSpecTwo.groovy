package org.easyspec.domain

import org.easyspec.EasySpec
import org.easyspec.Context
import org.easyspec.Behavior

@EasySpec(interest='TestSpec')
class IsSpecTwo {
	@Context("when context is two")
	public void setUp() {}

	@Behavior
	public void test_does_something() {}

}
