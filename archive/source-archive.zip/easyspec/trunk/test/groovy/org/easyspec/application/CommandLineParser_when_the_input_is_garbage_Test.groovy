package org.easyspec.application;

import org.easyspec.EasySpec;
import org.easyspec.Context;
import groovy.util.GroovyTestCase
import org.easyspec.Behavior;

@EasySpec(interest = 'CommandLine Parser')
public class CommandLineParser_when_the_input_is_garbage_Test extends GroovyTestCase {

    def thrownException

    @Context('when the input is garbage')
    void setUp() {
        def input = ['alksf']
        CommandLineParser parser = new CommandLineParser()
        try {
            parser.parse(input)
        } catch (e) {
            thrownException = e
        }
    }
    
    @Behavior
    void test_should_blow_up_with_a_reasonable_message() {
        assertNotNull(thrownException)
        assertEquals('Not sure what to do with the commandline option \'alksf\'.  Check your syntax.', thrownException.message)
    }
}
