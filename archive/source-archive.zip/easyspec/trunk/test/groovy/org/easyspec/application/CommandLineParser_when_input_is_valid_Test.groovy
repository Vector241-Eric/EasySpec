package org.easyspec.application

import org.easyspec.EasySpec
import org.easyspec.Context
import org.easyspec.Behavior

@EasySpec(interest = 'CommandLine Parser')
class CommandLineParser_when_input_is_valid_Test extends GroovyTestCase {

    Map results

    @Context('when the input has valid flags and values')
    public void setUp() {
        def input = ['--flag1', 'value1', '--flag2', 'value2', '-flag3']
        def parser = new CommandLineParser()
        results = parser.parse(input)
    }

    @Behavior
    public void test_should_find_every_flag_on_the_command_line() {
        assertEquals(3, results.size())
    }

    @Behavior
    public void test_should_extract_flags_with_a_double_dash_and_associate_them_with_their_argument_values() {
        assertEquals ('value1', results['flag1'])
        assertEquals ('value2', results['flag2'])
    }

    @Behavior
    public void test_should_extract_single_dash_flags_without_any_associated_value() {
        assertTrue(results['flag3'])
    }
}