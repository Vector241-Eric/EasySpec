package org.easyspec.domain

import org.easyspec.EasySpec
import org.easyspec.Context
import org.easyspec.Behavior
import org.easyspec.*

@EasySpec(interest='Spec Parser')
class SpecParser_given_a_valid_specification_Test extends GroovyTestCase {
	def specParser
	def input
	def specification

	@Context("when the input class is a specification")
	void setUp() {
		specParser = new SpecParser();
		input = this.class;
		specification = specParser.extractSpecFrom(input);
	}

	@Behavior
	void test_should_determine_that_it_is_a_specification() {
		assertTrue(specParser.isSpecification(input));
	}

	@Behavior
	void test_should_find_the_context() {
		assertEquals("when the input class is a specification", specification.getContext());
	}

    @Behavior
    void test_should_find_the_specification_interest() {
        assertEquals("Spec Parser", specification.getInterest());
    }

    @Behavior
    void test_should_find_the_specification_package() {
        assertEquals("org.easyspec.domain", specification.javaPackage);
    }

	@Behavior
	void test_should_find_individual_behaviors() {
      assertEquals(6, specification.getBehaviors().size());
      assertTrue(specification.getBehaviors().contains(new domain.Behavior(detail:"should determine that it is a specification")));
      assertTrue(specification.getBehaviors().contains(new domain.Behavior(detail:"should find the context")));
      assertTrue(specification.getBehaviors().contains(new domain.Behavior(detail:"should find the specification interest")));
      assertTrue(specification.getBehaviors().contains(new domain.Behavior(detail:"should find individual behaviors")));
      assertTrue(specification.getBehaviors().contains(new domain.Behavior(detail:"should track unimplemented behaviors")));
      assertTrue(specification.getBehaviors().contains(new domain.Behavior(detail:"should find the specification package")));
	}

	@Behavior(implemented=false)
	void test_should_track_unimplemented_behaviors() {
		def behavior = specification.behaviors.find { it.detail == 'should track unimplemented behaviors' }
		assertFalse('Behavior should be not implemented', behavior.isImplemented)
	}
}