package org.easyspec.domain

class IsNotSpec {
	def foo() {
		println 'foo'
	}
}