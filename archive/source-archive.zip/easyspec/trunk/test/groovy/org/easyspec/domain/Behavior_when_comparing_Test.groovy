package org.easyspec.domain

import org.easyspec.EasySpec
import org.easyspec.Context
import org.easyspec.Behavior
import org.easyspec.*

@EasySpec(interest='Behavior')
class Behavior_when_comparing_Test extends GroovyTestCase {
	domain.Behavior behavior1
	domain.Behavior behavior2

	@Context('when comparing')
	public void setUp() {
		behavior1 = new domain.Behavior(detail:'some detail')
		behavior2 = new domain.Behavior(detail:'some detail')
	}

	@Behavior
	public void test_should_indicate_behaviors_are_equal_when_all_characteristics_are_equal() {
		assertTrue(behavior1 == behavior2)
	}

	@Behavior
	public void test_should_indicate_inequality_if_behavior_details_are_different() {
		behavior1.detail = 'something else'
		assertFalse(behavior1 == behavior2)
	}

	@Behavior
	public void test_should_never_be_equal_to_something_that_is_not_a_behavior() {
		assertFalse(behavior1 == 'some string')
	}
}