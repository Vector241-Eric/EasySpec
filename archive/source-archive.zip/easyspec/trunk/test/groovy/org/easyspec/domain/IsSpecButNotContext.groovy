package org.easyspec.domain

import org.easyspec.EasySpec
import org.easyspec.Behavior

/**
 * Created by IntelliJ IDEA.
 * User: dea
 * Date: Dec 17, 2008
 * Time: 2:56:36 PM
 * To change this template use File | Settings | File Templates.
 */
@org.easyspec.EasySpec(interest="I am a specification")
class IsSpecButNotContext {

    // note that I have no context. Not good.

    @Behavior
    public void test_should_not_like_this() {
    
    }

}