package org.easyspec.domain

import org.easyspec.EasySpec
import org.easyspec.Context
import org.easyspec.Behavior
import org.easyspec.*

@EasySpec(interest='Specification Object')
class Specification_when_checking_equality_Test extends GroovyTestCase {

	Specification spec1
	Specification spec2

	@Context('when checking equality')
	public void setUp() {

		spec1 = new Specification()
		spec1.context = 'my context'
		spec1.interest = 'my interest'
		spec1.behaviors.add(new domain.Behavior(detail:'does foo'))

		spec2 = new Specification()
		spec2.context = 'my context'
		spec2.interest = 'my interest'
		spec2.behaviors.add(new domain.Behavior(detail:'does foo'))
	}

	@Behavior
	void test_should_indicate_that_the_specifications_are_equal() {
		assertTrue(spec1.equals(spec2))
	}

	@Behavior
	void test_should_not_consider_specifications_equal_if_their_contexts_differ() {
		spec1.context = 'something else'
		assertFalse(spec1.equals(spec2))
	}

	@Behavior
	void test_should_not_consider_specifications_equal_if_their_interests_differ() {
		spec1.interest = 'something else'
		assertFalse(spec1.equals(spec2))
	}

	@Behavior
	void test_should_not_consider_specifications_equal_if_their_behaviors_differ() {
		spec1.behaviors.add(new domain.Behavior(detail:'another behavior'))
		assertFalse(spec1.equals(spec2))
	}

	@Behavior
	void test_should_not_allow_comparison_with_an_object_that_is_not_a_specification() {
		assertFalse(spec1.equals('some string'))
	}
}