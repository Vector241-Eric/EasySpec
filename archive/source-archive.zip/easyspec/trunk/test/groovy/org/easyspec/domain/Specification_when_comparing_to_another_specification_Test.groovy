package org.easyspec.domain

import org.easyspec.EasySpec
import org.easyspec.Context
import org.easyspec.Behavior
import org.easyspec.*

@EasySpec(interest='Specification Object')
class Specification_when_comparing_to_another_specification_Test extends GroovyTestCase {

	Specification spec0
	Specification spec1
	Specification spec2
	Specification spec3

	def sortedSpecs = new ArrayList()

	@Context('when comparing Specifications')
	public void setUp() {

		spec0 = new Specification()
		spec0.interest = 'InterestF'
		spec0.context = 'ContextF'
		spec0.behaviors.add(new domain.Behavior(detail:'does foo', isImplemented:false))

		spec1 = new Specification()
		spec1.interest = 'InterestA'
		spec1.context = 'ContextD'
		spec1.behaviors.add(new domain.Behavior(detail:'does foo'))

		spec2 = new Specification()
		spec2.interest = 'InterestB'
		spec2.context = 'ContextB'
		spec2.behaviors.add(new domain.Behavior(detail:'does foo'))

		spec3 = new Specification()
		spec3.interest = 'InterestB'
		spec3.context = 'ContextC'
		spec3.behaviors.add(new domain.Behavior(detail:'does foo'))

		def set = new TreeSet()
		set.add(spec2)
		set.add(spec1)
		set.add(spec3)
		set.add(spec0)

		for (spec in set) {
			sortedSpecs.add(spec)
		}

		assertEquals('If compareTo is broken, we might lose some elements we expect to keep.', 4, sortedSpecs.size())
	}

	@Behavior
	void test_should_sort_unimplemented_specifications_first() {
		assertEquals(spec0, sortedSpecs.get(0))
	}

	@Behavior
	void test_should_sort_second_by_interest() {
		assertEquals(spec1, sortedSpecs.get(1))
		assertEquals(spec2, sortedSpecs.get(2))
	}

	@Behavior
	void test_should_sort_third_by_context() {
		assertEquals(spec2, sortedSpecs.get(2))
		assertEquals(spec3, sortedSpecs.get(3))
	}
}