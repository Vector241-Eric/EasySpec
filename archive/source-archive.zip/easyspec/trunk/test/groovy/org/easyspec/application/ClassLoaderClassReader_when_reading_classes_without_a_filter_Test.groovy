package org.easyspec.application

import org.easyspec.*
import groovy.mock.interceptor.MockFor

@EasySpec(interest='Class Loader Class Reader')
class ClassLoaderClassReader_when_reading_classes_without_a_filter_Test extends GroovyTestCase {
	def loadedClasses = new ArrayList()

	@Context('when reading classes without a filter')
	public void setUp() {
		def path = 'some/fake/path.jar'
		def testPaths = ["com/test/foo.class", "com/test/bar.class", "com/other/package.class"]
		def classLoader = [loadClass:{name, resolve ->
			assert resolve == true
			loadedClasses.add(name)
		}]
		def classLoaderFactory = [createClassLoader:{file -> classLoader}]
		
		def jarParser = [getEntryNames:{testPaths}]
		def reader = new ClassLoaderClassReader(classLoaderFactory:classLoaderFactory, jarParser:jarParser)
		loadedClasses = reader.readClasses(path)
	}

    @Behavior
    void test_should_load_all_classes_regardless_of_package_or_name() {
		assert loadedClasses.size() == 3
	}
}