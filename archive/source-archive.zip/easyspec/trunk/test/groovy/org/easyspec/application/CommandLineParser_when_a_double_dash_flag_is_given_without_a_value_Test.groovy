package org.easyspec.application

import org.easyspec.EasySpec
import org.easyspec.Context
import org.easyspec.Behavior

@EasySpec(interest = 'CommandLine Parser')
class CommandLineParser_when_a_double_dash_flag_is_given_without_a_value_Test extends GroovyTestCase {

    def thrownException

    @Context('when a double dash flag is given without an associated value')
    public void setUp() {
        def input = ['--flag1']
        def parser = new CommandLineParser()
        try {
            parser.parse(input)
        } catch (e) {
            thrownException = e
        }
    }

    @Behavior
    public void test_should_blow_up_with_a_reasonable_message() {
        assertNotNull (thrownException)
        assertEquals('Cannot find a value to match with --flag1', thrownException.message)
    }

}